"""Error vocabulary: re-exported from the shared runtime."""

from dataagent_runtime.errors import (  # noqa: F401
    CapabilityError,
    dependency_unavailable,
    execution_unknown,
    invalid_input,
    not_found,
    unsupported,
    version_conflict,
)

__all__ = [
    "CapabilityError",
    "invalid_input",
    "unsupported",
    "not_found",
    "version_conflict",
    "dependency_unavailable",
    "execution_unknown",
]
