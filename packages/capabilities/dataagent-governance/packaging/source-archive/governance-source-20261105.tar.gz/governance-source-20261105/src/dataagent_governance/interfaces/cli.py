"""CLI for the governance layer.

Two entry kinds:

- ``<operation>`` — capability calls, same wire shape as the data layer;
- ``confirm-criteria`` — the trusted-host management entry that activates a
  draft criteria (review §9). It is deliberately not an MCP tool: the repair
  flow must not be able to drive it from inside a model context.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from dataagent_contracts.core import CriteriaRef
from dataagent_runtime.interfaces.cli import main as _cli_main

from dataagent_governance import __version__
from dataagent_governance.registry import validate_registry
from dataagent_governance.runtime import default_runtime
from dataagent_governance.runtime.runtime import GovernanceRuntime

USAGE = """usage: python -m dataagent_governance.interfaces.cli <operation>
       python -m dataagent_governance.interfaces.cli --list
       python -m dataagent_governance.interfaces.cli confirm-criteria <criteria.json>

stdin: {"input": {...}, "context": {...}} or {"...input fields...", "context": {...}}
stdout: CapabilityResult JSON
exit: 0 for ok/partial/needs_input, 1 for failed, 2 for usage errors
"""


def _invoke(operation, payload, context):
    from dataagent_runtime.invoke import invoke

    return invoke(operation, payload, context, runtime=default_runtime())


def _list_operations():
    from dataagent_runtime.registry import list_operations

    from dataagent_governance.registry import load_operations

    load_operations()
    return list_operations()


def _confirm_criteria(body: dict[str, Any]) -> int:
    """Activate a draft with an authorized confirmation record.

    ``authorized_confirmers`` comes from the trusted host configuration
    (``DATAAGENT_CONFIRMERS``, comma-separated subject refs) — never from
    the JSON body.
    """

    from dataagent_governance.contracts import CriteriaConfirmation
    from dataagent_governance.evaluation.criteria_samples import (
        confirm_acceptance_criteria,
    )

    confirmers = {
        part.strip()
        for part in (os_environ("DATAAGENT_CONFIRMERS", "").split(","))
        if part.strip()
    }
    if not confirmers:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "issues": [
                        {
                            "code": "da12.access_denied",
                            "severity": "error",
                            "message": "no authorized confirmers configured "
                            "(DATAAGENT_CONFIRMERS); refusing to activate",
                            "retryable": False,
                        }
                    ],
                },
                ensure_ascii=False,
            )
        )
        return 1
    from dataagent_runtime.errors import CapabilityError

    try:
        confirmation = CriteriaConfirmation.model_validate(body.get("confirmation"))
        rt: GovernanceRuntime = default_runtime()
        ref: CriteriaRef = confirm_acceptance_criteria(
            rt,
            str(body["criteria_id"]),
            str(body["criteria_revision"]),
            confirmation,
            authorized_confirmers=confirmers,
        )
    except CapabilityError as exc:
        issue = exc.to_issue()
        print(
            json.dumps(
                {
                    "status": "failed",
                    "issues": [
                        {
                            "code": issue.code,
                            "severity": issue.severity.value,
                            "message": issue.message,
                            "retryable": issue.retryable,
                        }
                    ],
                },
                ensure_ascii=False,
            )
        )
        return 1
    print(json.dumps(ref.model_dump(mode="json"), ensure_ascii=False))
    return 0


def os_environ(name: str, default: str = "") -> str:
    import os

    return os.environ.get(name, default)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "confirm-criteria":
        try:
            validate_registry()
        except Exception as exc:  # noqa: BLE001
            print(f"dataagent-governance: registry check failed: {exc}", file=sys.stderr)
            return 1
        raw = sys.stdin.read()
        try:
            body = json.loads(raw) if raw.strip() else {}
        except json.JSONDecodeError as exc:
            print(f"invalid JSON on stdin: {exc.msg}", file=sys.stderr)
            return 2
        if not isinstance(body, dict):
            print("stdin JSON must be an object", file=sys.stderr)
            return 2
        return _confirm_criteria(body)
    return _cli_main(
        argv,
        list_operations=_list_operations,
        invoke=_invoke,
        validate=validate_registry,
        usage=USAGE,
        program="dataagent-governance",
    )


if __name__ == "__main__":
    raise SystemExit(main())
